# V6.54

La note courante et son PDF sont à la racine. Le dossier calculs/ conserve la passe scientifique originale et ses audits, avec sa première étiquette éditoriale V6.53. Aucune nouvelle borne globale n’est obtenue.
